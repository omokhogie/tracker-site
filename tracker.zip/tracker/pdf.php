 
<?php

$sender_name= "jack emeka";
$reciever_name= " john remi";
$reciever_phone= " 9428023023";
$reciever_address= " Plateau state";
$sender_phone= " 28738232";
$num_of_parcel= "1";
$kg= "55";
$postcode= "43872";
$address=" Ikeja lagos";
$identification_number=" 7950";
$special_service="700";
$vat= "400";
$invoice_reference= "23873294";
$charge_services= "800";
$country_from= "india";
$country_to= "Nigeria";
$total_paid= "7000";
$delivery_date= "20/11/25";
$delivery_time= "11:40pm";
$dimension= "12x5x90";
$extra_charge= "100";
$dispatch_date= "21/10/25";
$reciever_subdistrict= "bokko";


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/all.css">
    <title>Document</title>
</head>


<style>
.table{
    border: 1px solid red;
    width: 100%;

}
.box{
   text-align: center;
   background-color: red;
   color: aliceblue;
}
.bo{
   
   background-color: red;
   color: aliceblue;
}
.d1{
    height: 70px;
}
.d3{
    text-align: center;
}
.d4{
    color: red;
    text-align: center;
}
.purp{
    color: purple;
}
.note {
    color: red;
}
/* .red{
    background-color: red;
    color: aliceblue;
} */
</style>
<body>
    <div class="bod" >
        <table class="table " border="1" >
            <tr class="d1">
                <td  colspan="2"> Swift Service</td>
                <td colspan="4"> Cargo deliver</td>
            </tr>
            <tr>
                <td  class="bo"  colspan="2">1. Sender</td>
                <td class="box" colspan="2"> 4. Details of Goods and Services</td>
                <td class="box" colspan="2"> 5.  Dimensions/ Weight</td>
                <!-- <td colspan=" "> hello</td>
                <td> hello</td>
                <td> hello</td>
                <td> hello</td>
                <td> hello</td> -->
            </tr>
            <tr>
                <td rowspan=""> POST CODE <br> <?= $postcode ?> </td>
                <td> SENDER NAME <br> <?= $sender_name ?> </td>
                <td colspan="2" class="d3"> Not all payment and services are available in all</td>
             
                <td class="d3" rowspan="2"> <?= $num_of_parcel ?> <br>
                    TRUNK</td>
                <td class="d3" rowspan="2"> <?= $kg ?></td>
            </tr>
            <tr>
                <td class="d3" colspan="2">  Sender's Reference First characters will be shown on invoice <br> <?= $invoice_reference ?></td>
                
                <td class="d3"> Services</td>
                <td class="d3"> TRANSPORT CHARGES</td>
                <!-- <td> hello</td>
                <td> hello</td> -->
            </tr>
            <tr>
                <td colspan="2" >SENDER ADDRESS: <br> <?= $address ?> <br> <?= $country_to ?> </td>
                
                <td class="d3"> DIPLOMATIC DOCUMENT <br> WORLDWIDE DIPLOMATIC PACKAGE <br> DOMESTIC PACKAGE <br></td>
                <td class="d3"> <i>If lost back to sender </i><br> <i>pay transport charges</i> <br> Consignor <br></td>
                <td class="d3" colspan="2"> <b>Dimension in Inc IxIxH <br> <?= $dimension ?></b></td>
                
            </tr>
            <tr>
                <td> DISPATCH DATE <br><?= $dispatch_date ?> </td>
                <td> TEL/EMAIL <br> <?= $sender_phone ?></td>
                <td class="d3">  EXPRESS DOCUMENT <br> NATIONAL <br> WORLDMAIL  <br> OTHER SERVICES </td>
                <td class="d3">  <b> Cheque/ Credit Card <br> for approved customers only <br> Accord External Billing  <br> Transport Collect <br> SHIPMENT INSURANCE  <br> Yes</b></td>
                <td class="box" colspan="2"> 6. TOTAL EXPENDITURE </td>
                
            </tr>
            <tr>
                <td colspan="2" class="bo">2. DESTINATION</td>
                <td colspan="2" class="d4"> FULL DESCRIPTION OF CARDS</td>
                <td colspan="2" class="d3"> Volumetric Charged Weight <br> <?= $kg ?></td>
            </tr>
            <tr>
                <td colspan="2" class=""> Name <br> <?= $reciever_name ?> <hr> <?= $reciever_address ?> <br> <?= $reciever_subdistrict ?><br> <?= $reciever_phone ?></td>
                <td colspan="2" class="d4"> <b>- PERSONAL EFFECT -</b> <br> <h4 class="purp"> TO BE DELIVER WITHIN 24 HOURS</h4></td>
                <td  class="d3"> Code <br> HCW </td>
                <td  class="d3"> Charge Services <br> <?= $charge_services ?></td>
            </tr>
             <tr>
                 <td class="box" colspan="2"> 3. SENDERS AUTHORISED SIGNATURE</td>
                <td> Identification No: <br> <?= $identification_number ?> </td>
                <td> Sender's VATGST No <br> </td>
                <td class="d3"> DIP  </td>
                <td class="d3">  <b> Special <br> <?= $special_service ?></td>
                
            </tr>

            <tr>
                <td colspan="2">DELIVER TO MY SOLE BENEFICIARY</td>
                <td>Customers Officer's NO 31</td>
                <td colspan="">VAT identification at Destination:</td>
                <td class="d3"> ASS</td>
                <td class="d3"><?= $extra_charge ?></td>
            </tr>

            <tr>
                <td> DELIVERY TIME: <br> <?= $delivery_time ?></td>
                <td> DELIVERY DATE: <br><?= $delivery_date ?></td>
                <td colspan="2"> Types of Export PERMANENT REPAIR TEMPORARY</td>
                <td class="d3"> HCW </td>
                <td class="d3"> Other/Vat <br> <?= $vat ?></td>
            </tr>
            <tr>
                <td colspan="2">
                    Delivery Charges Details
        
                </td>
                <td class="d3" colspan="2">Reciever's VATGST no. </td>
                <td class="d3"> CODE <br> CURRENCY</td>
                <td class="d3"> TOTAL PAID <br><?= $total_paid ?></td>
            </tr>
            <tr>
                <td colspan="2"><b class="note">Note:</b> Every delivery charges should be paid to the delivery <br>personnel Assigned</td>
                <td class="" colspan=""> Destination </td>
                <td class="d3"> Sender Other's to:</td>
                <td colspan="2" class="d3"> TRANSPORT COLLECT STICKER NO: <br> DIP49. <?= $kg ?></td>
            </tr>
            <tr>
                <td colspan="2"></td>
                <td class="d3" colspan="2"> MAY EXPRESS COURIER</td>
                <td class="d3" colspan="2"> PACKAGE :<?= $sender_name ?> <br> <?= $country_from ?> -<?= $country_to ?> <br>  <h5> LOCAL CHARGES TO BE PAID <br> BY THE RECIEVER AND THE DEMURRAGE CHARGES AFTER <br>  THREE (3) DAYS OF FAILING TO <br> CLEAR THE VAULT BOX</h5></td>
            </tr>
        </table>
    </div>
</body>
</html>