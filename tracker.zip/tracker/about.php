<?php
$link = ["home", "about", "comment", "contact"];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>about</title>
    <link rel="stylesheet" href="css/style1.css">
    <link rel="stylesheet" href="css/style2.css">
    <!-- <link rel="stylesheet" href="/fontawesome-free-7.0.0-web/">  -->
</head>

<body>
    <div class="container">
        <div class="littlenav"></div>
        <!-- ///////////// -->
        <div class="bignav">
            <div class="logo">
                <h1>DELIVERI-X</h1>
            </div>
            <div class="logolink">
                <?php foreach ($link as $item): ?>
                    <a href="<?= $item ?>.php" class="logolinki"><?= " " . ucfirst($item) ?></a>
                <?php endforeach; ?>
            </div>
            <div class="toggle">
                <img src="image/menu.jpg" alt="" class="toggleimage">
                <div class="menu">
                    <?php foreach ($link as $item): ?>
                        <a href="<?= $item ?>.php" class="logolinki"><?= " " . ucfirst($item) ?></a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <!-- ////////////// -->
        <!-- <a href="">omokhogiesolomon3@gmail.com</a> -->
        <!-- <a href="mailto:omokhogiesolomon3@gmail.com">Send Email</a> -->
        <div class="about">
            <h1 class="aboutphead">About Us</h1>
            <p class="aboutptext">At DELIVERI-X, we are dedicated to making shipping fast, reliable, and stress-free. Whether it’s across the city, across the country, or across the globe, we handle your goods with care from pickup to delivery.

                Our mission is simple to connect people and businesses through safe, timely, and affordable shipping solutions. We combine modern tracking technology, efficient logistics planning, and a customer-first approach to ensure your shipments arrive exactly where they need to be, when they need to be there.

                With a passionate team and a network of trusted partners, we specialize in sea freight, air cargo, and land transportation, serving individuals, e-commerce sellers, and large businesses alike.

                At DELIVERI-X, your goods are more than just packages they’re promises. And we deliver on every promise.</p>
        </div>
        <div class="footer">
            <div class="footer1">
                <div class="equ">
                    <div class="equ1">
                        <h1 class="footerheader">Get In Touch</h1>
                        <p class="footertext" style="text-transform: lowercase;"> 6789 SOUTHPOINT PKWY STE 100 JACKSONVILLE FL 32216-8205, USA</p>
                        <p class="footertext"> +1 208 2304 730</p>
                        <p class="footertext"> deliverixy@gmail.com </p>
                    </div>
                    <div class="equ1">
                        <h1 class="footerheader">Quick Links</h1>
                        <?php foreach ($link as $item): ?>
                            <a href="<?= $item ?>.php" class="footerlink">> <?= " " . ucfirst($item) ?></a>
                        <?php endforeach; ?>
                    </div>
                    <div class="equ2"></div>
                </div>
            </div>
            <div class="footer2">
                <p class="footerlittle">© deliveri-X. </p>
            </div>
        </div>
    </div>
</body>

</html>