<?php
$connetion = pg_connect("host=localhost dbname=tracker user=postgres password='velocity 9'");
if ($connetion) {
    // echo "uuu";
};
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $search = $_POST["search"];
}

$link = ["home", "about", "comment", "contact"];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home</title>
    <link rel="stylesheet" href="css/style1.css">
    <link rel="stylesheet" href="css/style2.css">
</head>

<body>
    <div class="container">
        <div class="littlenav"></div>
        <!-- ///////////// -->
        <div class="bignav">
            <div class="logo">
                 <h1>DELIVERI-X</h1>
            </div>
            <div class="logolink">
                <?php foreach ($link as $item): ?>
                    <a href="<?= $item ?>.php" class="logolinki"><?= " " . ucfirst($item) ?></a>
                <?php endforeach; ?>
            </div>
            <div class="toggle">
                <img src="image/menu.jpg" alt="" class="toggleimage">
                <div class="menu">
                    <?php foreach ($link as $item): ?>
                        <a href="<?= $item ?>.php" class="logolinki"><?= " " . ucfirst($item) ?></a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <!-- ////////////// -->
        <div class="banner">
            <div class="layer">
                <div class="layer1">
                    <h3 class="text">Safe & Faster</h3>
                    <h2 class="text">Logistics Services</h2>
                    <p>Handcrated with love by the fine folks at</p>
                    <form action="home.php" method="post">
                        <input type="text" name="search" class="search" placeholder="Enter your tracking number">
                        <input type="submit" value="Track Now" class="but">
                    </form>
                </div>
            </div>
        </div>
        <!-- ////////////// -->
        <?php if (empty($search)): ?>
        <?php else: ?>
            <?php if ($_SERVER["REQUEST_METHOD"] == "POST"): ?>
                <?php
                $check = "SELECT * FROM tracker_user WHERE id = $1";
                $result = pg_query_params($connetion, $check, array($search));
                $destination = "SELECT * FROM dest WHERE id = $1";
                $result1 = pg_query_params($connetion, $destination, array($search));
                ?>
                <?php if (pg_num_rows($result) > 0): ?>
                    <?php
                    $row = pg_fetch_assoc($result);
                    $status = $row['status']; // Assuming 'status' is a column in your tracker_user table
                    ?>
                    <div class="map">
                        <div class="list">
                            <div class="trackid">
                                <h3 class="track">Tracking ID: <?php echo htmlspecialchars($search); ?></h3>
                            </div>
                            <!-- //////////// -->
                            <div class="main">
                                <div class="from">
                                    <h3 class="fromtext">From</h3>
                                    <h3 class="county"><?= $row['sender_name']  ?></h3>
                                    <p class="address"><?= $row['sender_address'] ?></p>
                                    <p class="address"><?= $row['sender_country'] ?></p>
                                    <!-- .................. -->
                                    <p class="address">Phone: <?= $search ?></p>
                                    <p class="address">Email: <?= "Box" ?></p>
                                    <!-- ..................... -->
                                </div>
                                <div class="to">
                                    <h3 class="fromtext">To</h3>
                                    <h3 class="county"><?= $row['reciever_name'] ?></h3>
                                    <p class="address"><?= $row['reciever_address'] ?></p>
                                    <p class="address"><?= $row['reciever_country'] ?></p>
                                    <p class="address">Phone: <?= $row['reciever_phone'] ?></p>
                                    <p class="address">Email: <?= $row['reciever_email'] ?></p>
                                </div>
                                <div class="shipment">
                                    <h3 class="fromtext">Shipment detail</h3>
                                    <h3 class="county">Tracking ID: <?= $search ?></h3>
                                    <p class="address">Content type <?= $row['content_type']  ?></p>
                                    <p class="address">Freight: <?= $row['freight'] ?></p>
                                    <p class="address">Weight: <?= $row['weight'] . "KG" ?></p>
                                </div>
                            </div>
                            <!-- ///////////////////// -->
                            <div class="barplace">
                                <div class="barcode">
                                    <img src="/image/barcode.webp" alt="" class="barcodeimage">
                                    <p class="barnumber">123456789</p>
                                </div>
                                <div class="status">
                                    <p class="shiptext">Shipment Stauts:</p>
                                    <?php if ($status == "pending"): ?>
                                        <div class="statuscolor" style="background-color: orangered;">
                                            <p>pending</p>
                                        </div>
                                    <?php elseif ($status == "Recieve"): ?>
                                        <div class="statuscolor" style="background-color: orange;">
                                            <p>Recieved</p>
                                        </div>
                                    <?php elseif ($status == "on board"): ?>
                                        <div class="statuscolor" style="background-color: black;">
                                            <p>on board</p>
                                        </div>

                                    <?php elseif ($status == "in town"): ?>
                                        <div class="statuscolor" style="background-color: lightgreen;">
                                            <p>in town</p>
                                        </div>
                                    <?php elseif ($status == "in country"): ?>
                                        <div class="statuscolor" style="background-color: blue;">
                                            <p>in country</p>
                                        </div>

                                    <?php elseif ($status == "delivered"): ?>
                                        <div class="statuscolor" style="background-color: green;">
                                            <p>delivered</p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="exp">
                                    <div class="goodimage" style="display: none;">
                                        <img src="/image/about.jpg" alt="" class="goodimage1" style="display: none;">
                                    </div>
                                    <div class="good">
                                        <p class="address">Expected delivery date: <?= $row['datetimee'] ?></p>
                                    </div>
                                </div>
                                <div class="destination">
                                    <p class="shiptext">Destination:</p>
                                    <p class="address"><?= $row['reciever_address'] . "," . $row['reciever_country'] ?></p>
                                </div>
                            </div>
                            <!-- /////////// -->
                            <div class="time">
                                <div class="date">
                                    <div class="no1">
                                        <p class="stext">Time/Date</p>
                                    </div>
                                    <div class="no2">
                                        <p class="stext">Description</p>
                                    </div>
                                </div>
                                <div class="board">
                                    <div class="no1">
                                        <p class="stext"><?= $row['datetimes'] ?></p>
                                    </div>
                                    <div class="no2">
                                        <div class="long" style="background-color: black;">
                                            <p>Shipped form <?= $row['sender_country'] ?></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="enter">
                                    <div class="no1">
                                        <p class="stext"><?= $row['datetimee'] ?></p>
                                    </div>
                                    <div class="no2">
                                        <div class="long" style="background-color: green;">
                                            <?php if (pg_num_rows($result1) > 0): ?>
                                                <?php $row1 = pg_fetch_assoc($result1); ?>
                                                <p>Currently in <?= $row1['direction'] ?></p>
                                            <?php else: ?>
                                                <p>Currently in <?= $row['sender_country'] ?></p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- ///////////////// -->
                        </div>
                        <div class="mapimage">
                            <!-- API -->
                        </div>
                    </div>
                <?php else: ?>
                    <div class="trackid" style="width: 99%; height:100px;">
                        <p class="track"><?= "These tracker id $search was not found" ?></p>
                    </div>
                <?php endif; ?>

            <?php endif; ?>
        <?php endif; ?>
        <!-- ///////////// -->
        <div class="scroll">
            <div class="empty">
                <a href="https://wa.me/+12082304730" class="whats"><img src="image/whatsapp.jpg" alt="" class="whatsapp"></a>
            </div>
        </div>
        <!-- ////////////// -->
        <div class="homepagemore">
            <div class="trukimage"></div>
            <div class="truktext">
                <p class="homeabout">about us</p>
                <h2 class="head">Trusted & Faster Logistic Service Provider</h2>
                <p class="hometext">At [Your Company Name], we are dedicated to making shipping fast, reliable, and stress-free. Whether it’s across the city, across the country, or across the globe, we handle your goods with care from pickup to delivery.</p>
                <p class="hometext">Contact us today and let us know how we can help you.</p>
                <div class="aboutmore">
                    <a href="/about.php" class="more">more</a>
                </div>
            </div>

        </div>
        <div class="footer">
            <div class="footer1">
                <div class="equ">
                    <div class="equ1">
                        <h1 class="footerheader">Get In Touch</h1>
                        <p class="footertext" style="text-transform: lowercase;"> 6789 SOUTHPOINT PKWY STE 100 JACKSONVILLE FL 32216-8205, USA</p>
                        <p class="footertext">+1 208 2304 730</p>
                        <p class="footertext"> deliverixy@gmail.com </p>
                    </div>
                    <div class="equ1">
                        <h1 class="footerheader">Quick Links</h1>
                        <?php foreach ($link as $item): ?>
                            <a href="<?= $item ?>.php" class="footerlink">> <?= " " . ucfirst($item) ?></a>
                        <?php endforeach; ?>
                    </div>
                    <div class="equ2"></div>
                </div>
            </div>
            <div class="footer2">
                <p class="footerlittle">© deliveri-X. </p>
            </div>
        </div>
    </div>
</body>

</html>