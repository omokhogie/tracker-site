<?php
$link = ["home", "about", "comment", "contact"];
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullName = $_POST["full-name"] ?? '';
    $email = $_POST["email"] ?? '';
    $comment = $_POST["comment"] ?? '';

    // Validate the inputs
    if (!empty($fullName) && !empty($email) && !empty($comment)) {
        // Email details
        
            $successMessage = "Your message has been sent successfully!";
        
    } else {
        $errorMessage = "Please fill in all fields.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>contact</title>
    <link rel="stylesheet" href="css/style1.css">
    <link rel="stylesheet" href="css/style2.css">
</head>

<body>
    <div class="container">
        <div class="littlenav"></div>
        <!-- ///////////// -->
        <div class="bignav">
            <div class="logo">
                <h1>DELIVERI-X</h1>
            </div>
            <div class="logolink">
                <?php foreach ($link as $item): ?>
                    <a href="<?= $item ?>.php" class="logolinki"><?= " " . ucfirst($item) ?></a>
                <?php endforeach; ?>
            </div>
            <div class="toggle">
                <img src="image/menu.jpg" alt="" class="toggleimage">
                <div class="menu">
                    <?php foreach ($link as $item): ?>
                        <a href="<?= $item ?>.php" class="logolinki"><?= " " . ucfirst($item) ?></a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <!-- ////////////// -->
        <div class="contact">
            <div class="contact1">
                <?= $errorMessage ??""?>
                <form action="/contact.php" method="post">
                    <input type="text" class="search2" name="full-name" placeholder="fulltname">
                    <input type="text" name="email" class="search2" placeholder="email">
                    <textarea name="comment" class="comment1"></textarea>
                    <input type="submit" value="send" class="but" style="margin-top:5px;">
                </form>
            </div>
            <div class="contact1">
                <div class="contact2">
                    <h2 class="con-header">Contact Info</h2>
                    <p class="con-text">Address:</p>
                    <p class="con-litt">34 Street Name, City Name Here, United States</p>
                    <p class="con-text">Phone:</p>
                    <p class="con-litt">+1 208 2304 730</p>
                    <p class="con-text">Email:</p>
                    <p class="con-litt">deliverixy@gmail.com</p>
                    <p class="con-text">whatsapp:</p>
                    <p class="con-litt">+1 208 2304 730</p>
                </div>
            </div>
        </div>
        <div class="footer">
            <div class="footer1">
                <div class="equ">
                    <div class="equ1">
                        <h1 class="footerheader">Get In Touch</h1>
                        <p class="footertext" style="text-transform: lowercase;"> 6789 SOUTHPOINT PKWY STE 100 JACKSONVILLE FL 32216-8205, USA</p>
                        <p class="footertext">+1 208 2304 730</p>
                        <p class="footertext"> deliverixy@gmail.com </p>
                    </div>
                    <div class="equ1">
                        <h1 class="footerheader">Quick Links</h1>
                        <?php foreach ($link as $item): ?>
                            <a href="<?= $item ?>.php" class="footerlink">> <?= " " . ucfirst($item) ?></a>
                        <?php endforeach; ?>
                    </div>
                    <div class="equ2"></div>
                </div>
            </div>
            <div class="footer2">
                <p class="footerlittle">© deliveri-X. </p>
            </div>
        </div>
    </div>
</body>

</html>