<?php
$connetion = pg_connect("host=localhost dbname=tracker user=postgres password='velocity 9'");
if ($connetion) {
    // echo "uuu";
};
$id = $_GET["s"] ?? "";
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $check = "SELECT * FROM tracker_user WHERE id = $1";
    $result = pg_query_params($connetion, $check, array($id));
    if (pg_num_rows($result) > 0) {
        $row = pg_fetch_assoc($result);
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style1.css">
    <link rel="stylesheet" href="css/style2.css">
</head>

<body>
    <div class="container">
        <div class="littlenav"></div>
        <div class="list-comment" style=" align-items: start;">
            <h3><?= $id ?></h3>
            <p class="lip" style="color: blue;"><?= "sender name:" . " " . $row["sender_name"]??"" ?></p>
            <p class="lip" style="color: red;"><?= "reciever name:" . " " . $row["reciever_name"]??"" ?></p>
            <p class="lip"> <?= "reciever phone:" . " " . $row["reciever_phone"]??"" ?></p>
            <p class="lip"><?= "reciever email:" . " " . $row["reciever_email"]??"" ?></p>
            <p class="lip" style="color: red;"> <?= "reciever address:" . " " . $row["reciever_address"]??"" ?></p>
            <p class="lip" style="color: blue;"> <?= "reciever country:" . " " . $row["reciever_country"]??""  ?></p>
            <p class="lip" style="color: brown;"> <?= "content-type:" . " " . $row["content_type"]??"" ?></p>
            <p class="lip"> <?= "date and time the good was send:" . " " . $row["datetimes"] ??""?></p>
            <p class="lip" style="color: red;"> <?= "Expected delivery date:" . " " . $row["datetimee"]??"" ?></p>
            <p class="lip" style="color: red;"> <?= "status:" . " " . $row["status"]??"" ?></p>

        </div>
        <div class="green" style="margin-bottom: 5px;">
            <a href="admin.php?s=<?=  $_GET["s"] ?>">update</a>
        </div>
        <div class="green" style="background-color: red; color: white; border: none;">
            <a href="delete.php?s=<?= $_GET["s"] ?>">Delete</a>
        </div>
    </div>
</body>

</html>