<?php
session_start();
$connetion = pg_connect("host=localhost dbname=tracker user=postgres password='velocity 9'");
if ($connetion) {
    // echo "uuu";
};
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $use = $_POST["username"];
    $pass = $_POST["password"];
    if (empty($use) && empty($pass)) {
        $error = "please input your password and username";
    } else {
        $check = "SELECT * FROM block WHERE user_name=$1 AND password=$2";
        $result = pg_query_params($connetion, $check, array($use, $pass));
        if (pg_num_rows($result) > 0) {
            $error = "you are not allow to login...";
        } else {
            $check = "SELECT * FROM allow WHERE user_name=$1 AND password=$2";
            $result = pg_query_params($connetion, $check,array($use, $pass));
            if (pg_num_rows($result) > 0) {
                $_SESSION["user_name"]=pg_fetch_assoc($result);
                header("location:admin.php");
                
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style1.css">
    <link rel="stylesheet" href="css/style2.css">
</head>

<body>
    <div class="container heig">
        <?php if (empty($_GET["s"])): ?>
            <p><?= $error ?? "" ?></p>
            <form action="login.php" method="post" class="loginpage">
                <input type="text" name="username" id="" class="search2" placeholder="username">
                <input type="text" name="password" id="" class="search2" placeholder="password">
                <input type="submit" value="login" class="but mar">
                <a href="login.php?s=reg" class="mar">register a new account</a>
            </form>
        <?php else: ?>
            <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $trackingId = $_POST["tracking_id"];
                $name = $_POST["username"];
                $email = $_POST["email"];
                $pass = $_POST["password"];
                $con = $_POST["con-password"];
                if (empty($name) || empty($email) || empty($pass) || empty($con)) {
                    $error = "please all field are required....";
                } else {
                    if ($pass == $con) {
                        $insert = 'INSERT INTO reg(email,user_name, password,con) VALUES($1,$2,$3,$4)';
                        $result = pg_query_params($connetion, $insert, array($email, $name, $pass, $con));
                        if ($result) {
                            header("location:login.php");
                        } else {
                            $error = "an error occur!";
                        }
                    } else {
                        $error = "the password and comfirm password must be the same!";
                    }
                }
            }
            ?>
            <p><?= $error ?? "" ?></p>
            <form action="login.php?s=reg" method="post" class="loginpage">
                <input type="text" name="username" id="" class="search2" placeholder="username">
                <input type="email" name="email" id="" class="search2" placeholder="email">
                <input type="text" name="password" id="" class="search2" placeholder="password">
                <input type="text" name="con-password" id="" class="search2" placeholder="confirm password">
                <input type="submit" value="register" class="but mar">
                <a href="login.php" class="mar">already have an account</a>
            </form>
        <?php endif ?>
    </div>
</body>

</html>