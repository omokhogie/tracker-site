<?php
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $connetion = pg_connect("host=localhost dbname=tracker user=postgres password='velocity 9'");
    if ($connetion) {
        // echo "uuu";
    };
    $check = "SELECT * FROM reg WHERE  user_name=$1";
    $result = pg_query_params($connetion, $check, array($_GET["s"]));
    if (pg_num_rows($result) > 0) {
        $row = pg_fetch_assoc($result);
        $insert = 'INSERT INTO allow (email,user_name, password,con) VALUES($1,$2,$3,$4)';
        $result = pg_query_params($connetion, $insert, array($row["email"], $row["user_name"], $row["password"], $row["con"]));
        if ($result) {
            $deleteQuery = "DELETE FROM reg WHERE email = $1";
            $deleteResult = pg_query_params($connetion, $deleteQuery, array($row["email"]));
            header("location:admin.php?s=block");
            exit;
        } else {
            echo "an error occur!";
        }
    } else {
        $check = "SELECT * FROM block WHERE user_name=$1";
        $result = pg_query_params($connetion, $check, array($_GET["s"]));
        if (pg_num_rows($result) > 0) {
           $row = pg_fetch_assoc($result);
        $insert = 'INSERT INTO allow (email,user_name, password,con) VALUES($1,$2,$3,$4)';
        $result = pg_query_params($connetion, $insert, array($row["email"], $row["user_name"], $row["password"], $row["con"]));
        if ($result) {
            $deleteQuery = "DELETE FROM block WHERE email = $1";
            $deleteResult = pg_query_params($connetion, $deleteQuery, array($row["email"]));
            header("location:admin.php");
            exit;
        } else {
            echo "an error occur!";
        }
        }
    }
}
