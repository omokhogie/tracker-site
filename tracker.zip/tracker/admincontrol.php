<?php
$connetion = pg_connect("host=localhost dbname=tracker user=postgres password='velocity 9'");
if ($connetion) {
    // echo "uuu";
};
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style1.css">
    <link rel="stylesheet" href="css/style2.css">
</head>

<body>
    <div class="container">
        <?php if ($_GET["s"] == "block"): ?>
            <?php
            $check = "SELECT * FROM block";
            $result = pg_query($connetion, $check);
            $list_id = [];

            while ($row = pg_fetch_assoc($result)) {
                array_push($list_id, $row["user_name"]);
            }
            ?>
            <div class="bignav" style=" background-color:rgb(238, 238, 238);">
                <div class="logo">
                    <h1>Block</h1>

                </div>
            </div>
            <div class="container1">
                <div class="page1"></div>
                <div class="page2">
                    <div class="adminmain">
                        <div class="admintrackid" style="align-items: center; ">
                            <?php foreach ($list_id as $key => $sup): ?>
                                <div class="adminlist1" style="position: sticky; top:0px; ">
                                    <div class="sug-number">name: <?=$sup?></div>
                                    <div class="sug-button">
                                        <div class="green">
                                            <a href="allow.php?s=<?= $sup ?>">Allow</a>
                                        </div>

                                    </div>

                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php elseif ($_GET["s"] == "allow"): ?>
            <?php
            $check = "SELECT * FROM allow";
            $result = pg_query($connetion, $check);
            $list_id = [];

            while ($row = pg_fetch_assoc($result)) {
                array_push($list_id, $row["user_name"]);
            }
            ?>
            <div class="bignav" style=" background-color:rgb(238, 238, 238);">
                <div class="logo">
                    <h1>Allow</h1>
                </div>
            </div>
            <div class="container1">
                <div class="page1"></div>
                <div class="page2">
                    <div class="adminmain">
                        <div class="admintrackid" style="align-items: center; ">
                             <?php foreach ($list_id as $key => $sup): ?>
                            <div class="adminlist1" style="position: sticky; top:0px; ">
                                <div class="sug-number">name: <?=$sup?></div>
                                <div class="sug-button">
                                    <div class="green" style="background-color: red;margin-left: 10px;">
                                        <a href="block.php?s=<?= $sup ?>">Block</a>
                                    </div>
                                </div>

                            </div>
                            <?php endforeach; ?>    
                        </div>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <!-- default  -->
        <?php endif ?>
    </div>
</body>

</html>