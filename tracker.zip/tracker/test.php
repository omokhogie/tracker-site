
<?php
use Picqer\Barcode\BarcodeGeneratorPNG;

$generator = new BarcodeGeneratorPNG();
file_put_contents('barcode.png', $generator->getBarcode('123456789', $generator::TYPE_CODE_128));
?>