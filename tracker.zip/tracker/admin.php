<?php
session_start();
if (empty($_SESSION["user_name"])) {
    header("location:login.php");
}
$connetion = pg_connect("host=localhost dbname=tracker user=postgres password='velocity 9'");
if ($connetion) {
    // echo "uuu";
};
$check = "SELECT * FROM tracker_user";
$result = pg_query($connetion, $check);
$list_id = [];
while ($row = pg_fetch_assoc($result)) {
    array_push($list_id, $row["id"]);
}

$list = ["tracking id", "register", "shipment update", "shipment delete", "comments", "list of user", "block", "logout"];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admin</title>
    <link rel="stylesheet" href="css/style1.css">
    <link rel="stylesheet" href="css/style2.css">
</head>

<body>
    <div class="container">
        <div class="bignav" style=" background-color:rgb(238, 238, 238);">
            <div class="logo">
                <h1>Admin Dashboard</h1>
            </div>
            <div class="searchdiv">
                <form action="admin.php" method="post">
                    <input type="text" name="search" class="search1" placeholder="Enter the tracking number">
                    <input type="submit" value="Search" class="but">
                </form>
            </div>
            <div class="toggle">
                <img src="image/menu.jpg" alt="" class="toggleimage">
                <div class="menu" style=" background-color: rgba(193, 127, 46,0.9); top:80px; width: 60%;">
                    <form action="admin.php" method="post">
                        <input type="text" name="search" class="search1" placeholder="Enter the tracking number">
                        <input type="submit" value="Search" class="but" style="margin-top: 5px; width: 80px; height: 30px;">
                    </form>
                    <?php foreach ($list as $item): ?>
                        <a href="admin.php?s=<?= $item ?>" class="adminlist">
                            <div class="adminlistdiv">
                                <p style="margin-left: 5px;"><?= $item ?></p>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <div class="container1">
            <div class="page1">

                <?php foreach ($list as $item): ?>
                    <a href="admin.php?s=<?= $item ?>" class="adminlist">
                        <div class="adminlistdiv">
                            <p style="margin-left: 5px;"><?= $item ?></p>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
            <div class="page2">
                <?php if (empty($_GET["s"])): ?>
                    <?php if (empty($_POST["search"])): ?>
                        <div class="adminmain">
                            <p>welcome <?= $_SESSION["user_name"]["user_name"] ?? "" ?></p>
                        </div>
                    <?php else: ?>
                        <?php if ($_POST["search"] == "123456admin"): ?>
                            <div class="adminmain">
                                <div class="admintrackid" style="align-items: center; ">
                                    <div class="adminlist1" style="position: sticky; top:0px; ">
                                        <div class="sug-number"></div>
                                        <div class="sug-button">
                                            <div class="green">
                                                <a href="admincontrol.php?s=<?= "allow" ?>">Allow</a>
                                            </div>
                                            <div class="green" style="background-color: red;margin-left: 10px;">
                                                <a href="admincontrol.php?s=<?= "block" ?>">Block</a>
                                            </div>
                                        </div>

                                    </div>

                                </div>
                            </div>
                        <?php else: ?>
                            <?php if ($_SERVER["REQUEST_METHOD"] == "POST"): ?>
                                <?php
                                $check = "SELECT * FROM tracker_user WHERE id = $1";
                                $result = pg_query_params($connetion, $check, array($_POST["search"]));
                                ?>
                                <?php if (pg_num_rows($result) > 0): ?>
                                    <?php $row = pg_fetch_row($result); ?>
                                    <div class="adminmain">
                                        <div class="admintrackid" style="align-items: center;">
                                            <p class="tracktext">User</p>
                                            <div class="adminlist1">
                                                <div class="sug-number">
                                                    <p><?= $_POST["search"] ?></p>
                                                </div>
                                                <div class="sug-button">
                                                    <div class="green">
                                                        <a href="view.php?s=<?= $_POST["search"] ?>">View</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="adminmain">
                                        <p>the tracker number: <?= $_POST["search"] ?> was not founded </p>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php elseif ($_GET["s"] == "tracking id"): ?>
                    <div class="adminmain">
                        <div class="admintrackid" style="align-items: center;">
                            <p class="tracktext">Generate Tracking ID</p>
                            <div class="generator">
                                <?php
                                if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["generate_id"])) {
                                    $check = "SELECT * FROM tracker_user WHERE id = $1";
                                    $uniqueId = "UNS-" . mt_rand(100000, 999999); // Generates a random 6-digit number
                                    $result = pg_query_params($connetion, $check, array($uniqueId));
                                    if (empty($uniqueId)) {
                                        $good = "UNS-" . $uniqueId ?? ""; // Display the generated ID
                                    } else {

                                        if (pg_num_rows($result) > 0) {

                                            $good = "UNS-" . mt_rand(100000, 999999); // Regenerate if ID already exists
                                        } else {
                                            $good =  $uniqueId; // Generate a new unique ID
                                        }
                                        // Display a default ID if none is generated
                                    }
                                }
                                ?>
                                <form action="admin.php?s=tracking id" method="post" class="generator">
                                    <div class="gen">
                                        <?php
                                        echo $good ?? ""; // Display the generated ID or a default value
                                        ?>
                                    </div>
                                    <button type="submit" name="generate_id" class="but" style="width: 100px;">Generate ID</button>
                                </form>
                            </div>

                        </div>
                    </div>
                <?php elseif ($_GET["s"] == "register"): ?>
                    <div class="adminmain">
                        <div class="admintrackid" style="align-items: center;">
                            <p>Register Shipment</p>
                            <?php
                            if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["tracking_id"])) {
                                $trackingId = $_POST["tracking_id"];
                                $namer = $_POST["namer"];
                                $names = $_POST["names"];
                                $email = $_POST["email"];
                                $phone = $_POST["phone"];
                                $countryr = $_POST["countryr"];
                                $countrys = $_POST["countrys"];
                                $from = $_POST["from"];
                                $to = $_POST["to"];
                                $content_type = $_POST["content_type"];
                                $weight = $_POST["weight"];
                                $datetimes = $_POST["datetimes"];
                                $datetimee = $_POST["datetimee"];
                                $freight = $_POST["freight"];
                                if (empty($trackingId) || empty($namer) || empty($names) || empty($email) || empty($phone) || empty($countryr) || empty($countrys) || empty($from) || empty($to) || empty($content_type) || empty($weight) || empty($datetimes) || empty($datetimee)) {
                                    echo "Please make sure you input all required fields.";
                                } else {
                                    $insert = "INSERT INTO tracker_user (id, Reciever_name, Sender_name, Reciever_Email, Reciever_Phone, Reciever_country, Sender_country, Reciever_address, Sender_address, content_type, weight, datetimes, datetimee, freight,status) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)";
                                    $quer = pg_query_params($connetion, $insert, array($trackingId, $namer, $names, $email, $phone, $countryr, $countrys, $from, $to, $content_type, $weight, $datetimes, $datetimee, $freight, "Recieve"));
                                    if ($quer) {
                                        echo "Registration successful! ";
                                    } else {
                                        echo "Error: Could not register.";
                                    }
                                }
                            }
                            ?>
                            <form action="admin.php?s=register" method="post" class="admintrackid">
                                <input type="text" name="tracking_id" class="search2" placeholder="Enter Tracking ID">
                                <input type="text" name="namer" class="search2" placeholder="Reciever full name">
                                <input type="text" name="names" class="search2" placeholder="Sender full name">
                                <input type="email" name="email" class="search2" placeholder="Reciever Email address">
                                <input type="text" name="phone" class="search2" placeholder="Reciever Phone number">
                                <input type="text" name="countryr" class="search2" placeholder="Reciever country">
                                <input type="text" name="countrys" class="search2" placeholder="Sender country">
                                <input type="text" name="from" class="search2" placeholder="Receiver address">
                                <input type="text" name="to" class="search2" placeholder="Sender address">
                                <input type="text" name="content_type" class="search2" placeholder="Content type">
                                <input type="text" name="weight" class="search2" placeholder="Weight of the shipment">
                                <label for="datetimes">Select date and time for shipment start</label>
                                <input type="datetime-local" name="datetimes" id="datetimes" class="search2">
                                <label for="datetimee">Select date and time for shipment end</label>
                                <input type="datetime-local" name="datetimee" id="datetimee" class="search2">
                                <select name="freight" class="search1" style="margin-top: 10px;">
                                    <option value="Sea freight">Sea freight</option>
                                    <option value="Air freight">Air freight</option>
                                    <option value="Land freight">Land freight</option>
                                </select>
                                <input type="submit" value="Register" class="but" style="margin-top: 10px;">
                        </div>
                    </div>
                <?php elseif ($_GET["s"] == "shipment update"): ?>
                    <div class="adminmain">
                        <div class="admintrackid" style="align-items: center;">
                            <p>Shipment Update</p>
                            <?php foreach ($list_id as $key => $lists): ?>
                                <div class="adminlist1">
                                    <div class="sug-number">
                                        <p><?= $lists ?></p>
                                    </div>
                                    <div class="sug-button">

                                        <div class="green">
                                            <a href="admin.php?s=<?= $lists ?>">update</a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php elseif ($_GET["s"] == "shipment delete"): ?>
                    <div class="adminmain">

                        <div class="admintrackid" style="align-items: center;">
                            <p>Shipment Delect</p>
                            <?php foreach ($list_id as $key => $lists): ?>
                                <div class="adminlist1">
                                    <div class="sug-number">
                                        <p><?= $lists ?></p>
                                    </div>
                                    <div class="sug-button">
                                        <div class="green" style="background-color: red; color: white; border: none;">
                                            <a href="delete.php?s=<?= $lists ?>">Delete</a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php elseif ($_GET["s"] == "comments"): ?>
                    <div class="adminmain">
                        <div class="admintrackid" style="align-items: center;">
                            <p class="tracktext">Edit Comment</p>
                            <p class="tracktext"><?= $good ?? "" ?></p>
                            <?php
                            if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST["comment"])) {
                                $insert = "INSERT INTO comment2 (id, comment, direction) VALUES($1,$2,$3) ";
                                $que = pg_query_params($connetion, $insert, array($_SESSION["id"], $_POST["comment"], "send"));
                                if ($que) {
                                    echo "Successful edited comment";
                                    $deleteQuery = "DELETE FROM comment1 WHERE id = $1";
                                    $deleteResult = pg_query_params($connetion, $deleteQuery, array($_SESSION["id"]));
                                }
                            }
                            $check = "SELECT * FROM comment1";
                            $result = pg_query($connetion, $check);
                            $list_id = [];
                            $list_comment = [];
                            while ($row = pg_fetch_assoc($result)) {
                                array_push($list_id, $row["id"]);
                                array_push($list_comment, $row["comment"]);
                            }

                            ?>
                            <?php foreach ($list_id as $key => $listc): ?>
                                <form action="admin.php?s=<?= "comments" ?>" method="post">
                                    <?php
                                    $_SESSION["id"] = $listc; // Example tracking ID, replace with actual logic
                                    ?>
                                    <div class="search1" style="display: flex; align-items: center;"><?= $_SESSION["id"] ?></div>
                                    <textarea name="comment" class="comment"><?= $list_comment[$key] ?></textarea>
                                    <input type="submit" value="Update" class="green" style="margin-top: 10px; margin-bottom:5px;">
                                </form>
                            <?php endforeach ?>
                        </div>
                    </div>
                <?php elseif ($_GET["s"] == "list of user"): ?>
                    <div class="adminmain">
                        <div class="admintrackid" style="align-items: center;">
                            <p class="tracktext">User</p>
                            <?php foreach ($list_id as $key => $lists): ?>
                                <div class="adminlist1">
                                    <div class="sug-number">
                                        <p><?= $lists ?></p>
                                        <?php
                                        $_SESSION["id"] = $_GET["s"]; // Example tracking ID, replace with actual logic
                                        ?>
                                    </div>
                                    <div class="sug-button">
                                        <div class="green">
                                            <a href="view.php?s=<?= $lists ?>">View</a>
                                        </div>

                                    </div>

                                </div>
                            <?php endforeach; ?>

                        </div>
                    </div>

                <?php elseif ($_GET["s"] == "block"): ?>
                    <div class="adminmain">
                        <div class="admintrackid" style="align-items: center;">
                            <p class="tracktext">Admin control</p>
                            <?php
                            $check = "SELECT * FROM reg";
                            $result = pg_query($connetion, $check);
                            $list_id = [];

                            while ($row = pg_fetch_assoc($result)) {
                                array_push($list_id, $row["user_name"]);
                            }
                            ?>
                            <?php foreach ($list_id as $key => $sup): ?>
                                <div class="adminlist1">
                                    <div class="sug-number">
                                        <p><?= "name" . ": " . $sup ?></p>
                                    </div>
                                    <div class="sug-button">
                                        <div class="green">
                                            <a href="allow.php?s=<?= $sup ?>">Allow</a>
                                        </div>
                                        <div class="green" style="background-color: red;margin-left: 10px;">
                                            <a href="block.php?s=<?= $sup ?>">Block</a>
                                        </div>
                                    </div>

                                </div>
                            <?php endforeach; ?>

                        </div>
                    </div>
                <?php elseif ($_GET["s"] == "logout"): ?>
                    <div class="adminmain">
                        <?= $_GET["s"] ?>
                    </div>
                <?php else: ?>
                    <div class="adminmain">
                        <div class="admintrackid" style="align-items: center;">
                            <p>tracking_id: <?= $_GET["s"] ?></p>
                            <?php
                            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                                $check = "UPDATE tracker_user SET status = $1 WHERE id = $2";
                                $result = pg_query_params($connetion, $check, array($_POST["status"], $_GET["s"]));
                                if ($result) {
                                    echo "Status updated successfully!";
                                    if (empty($_POST["dest"])) {
                                    } else {
                                        $dest = $_POST["dest"];
                                        $insert = "INSERT INTO dest (id, direction ) VALUES($1,$2)";
                                        $quer = pg_query_params($connetion, $insert, array($_GET["s"], $dest));
                                    }
                                } else {
                                    echo "Error updating status.";
                                }
                            }

                            ?>
                            <div class="admintrackid" style="align-items: center;">
                                <form action="admin.php?s=<?= $_GET["s"] ?>" method="post" class="admintrackid">
                                    <div class="search3">
                                        <p>tracking_id: <?= $_GET["s"] ?></p>
                                    </div>
                                    <select name="status" class="search1" style="margin-top: 10px;">
                                        <option value="pending">pending</option>
                                        <option value="on board">on board</option>
                                        <option value="in country">in country</option>
                                        <option value="in town">in town</option>
                                        <option value="delivered">delivered</option>
                                    </select>
                                    <input type="text" name="dest" class="search2" placeholder="Enter Destination">
                                    <input type="submit" value="Update" class="but" style="margin-top: 10px;">
                                </form>

                            </div>
                        </div>

                    </div>
                <?php endif; ?>
            </div>
        </div>
</body>

</html>