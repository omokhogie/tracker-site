<!-- <?php
                            if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["view"])): ?>
                                <div class="space">
                                    <div class="p1">
                                        <p>Tracking ID: uns-123445</p>
                                        <p>Reciever Name: John Doe</p>
                                        <p>Reciever Phone Number: +1234567890</p>
                                        <p>Reciever Email:</p>
                                        <p>Reciever Country: USA</p>
                                        <p>Reciever Address: 123 Main St, Springfield jkdmpl'klk;j pdo'fkl//;lf/ p'dkl/k;/f'/fkl d['ld/;l/l;f/lk spo';'s';lk; idhfjlk;lmk;kjn</p>
                                        <p>Content Type: Electronics</p>
                                        <p>Weight: 2kg</p>
                                        <p>Date and Time Start: 2023-10-01 10:00</p>
                                        <p>Date and Time End: 2023-10-05 15:00</p>
                                        <p>Freight Type: Air freight</p>
                                        <p>Status: Pending</p>
                                    </div>
                                    <div class="p1">
                                        <p>Reciever Name: John Doe</p>
                                        <p>Reciever Phone Number: +1234567890</p>
                                        <p>Reciever Email:</p>
                                        <p>Reciever Country: USA</p>
                                        <p>Content Type: Electronics</p>
                                        <p>Date and Time Start: 2023-10-01 10:00</p>
                                    </div>
                                </div>

                            <?php endif; ?> -->
                      <a href="mailto:example@example.com">Send Email</a>