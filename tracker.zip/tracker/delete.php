<?php
$connetion = pg_connect("host=localhost dbname=tracker user=postgres password='velocity 9'");
if ($connetion) {
    // echo "uuu";
};
$lists=$_GET['s']??"";
if ($_SERVER["REQUEST_METHOD"] == "GET" && !empty($_GET['s']) ) {
    $deleteQuery = "DELETE FROM tracker_user WHERE id = $1";
    $deleteResult = pg_query_params($connetion, $deleteQuery, array($_GET['s']));
    if ($deleteResult) {
        echo "Shipment with ID $lists has been deleted successfully.";
    } else {
        echo "Error: Could not delete shipment with ID $lists.";
    }
}
