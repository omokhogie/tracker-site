<?php
session_start();
$connetion = pg_connect("host=localhost dbname=tracker user=postgres password='velocity 9'");
if (!$connetion) {
    die("Database connection failed.");
}

$link = ["home", "about", "comment", "contact"];

// Pagination variables
$recordsPerPage = 3; // Number of comments per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Current page number
$offset = ($page - 1) * $recordsPerPage; // Calculate the offset

// Handle comment submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST["comment"])) {
    $insert = "INSERT INTO comment1 (id, comment, direction) VALUES($1, $2, $3)";
    $que = pg_query_params($connetion, $insert, array($_SESSION["id"], $_POST["comment"], "send"));
    if ($que) {
        $good = "Comment added successfully!";
    }
}

// Fetch comments with pagination
$check = "SELECT * FROM comment2 LIMIT $1 OFFSET $2";
$result = pg_query_params($connetion, $check, array($recordsPerPage, $offset));
$list_id = [];
$list_comment = [];
while ($row = pg_fetch_assoc($result)) {
    array_push($list_id, $row["id"]);
    array_push($list_comment, $row["comment"]);
}

// Get total number of comments for pagination
$totalQuery = "SELECT COUNT(*) AS total FROM comment2";
$totalResult = pg_query($connetion, $totalQuery);
$totalRow = pg_fetch_assoc($totalResult);
$totalRecords = $totalRow['total'];
$totalPages = ceil($totalRecords / $recordsPerPage);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comment Page</title>
    <link rel="stylesheet" href="css/style1.css">
    <link rel="stylesheet" href="css/style2.css">
</head>

<body>
    <div class="container">
        <div class="littlenav"></div>
        <!-- Navigation -->
        <div class="bignav">
            <div class="logo">
                <h1>DELIVERI-X</h1>
            </div>
            <div class="logolink">
                <?php foreach ($link as $item): ?>
                    <a href="<?= $item ?>.php" class="logolinki"><?= ucfirst($item) ?></a>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Comment Section -->
        <div class="comment-con">
            <div class="add">
                <div class="but-com">
                    <a href="comment.php?s=add" class="addlink" style="font-weight:bold;">+</a>
                </div>
            </div>

            <?php if (empty($_GET["s"])): ?>
                <!-- Display Comments -->
                <?php foreach ($list_id as $key => $listc): ?>
                    <div class="list-comment">
                        <h3><?= htmlspecialchars($listc) ?> </h3>
                        <p><?= htmlspecialchars($list_comment[$key]) ?></p>
                    </div>
                <?php endforeach; ?>

                <!-- Pagination Links -->
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="comment.php?page=<?= $page - 1 ?>" class="page-link">Previous</a>
                    <?php endif; ?>

                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <a href="comment.php?page=<?= $i ?>" class="page-link <?= $i == $page ? 'active' : '' ?>">
                            <?= $i ?>
                        </a>
                    <?php endfor; ?>

                    <?php if ($page < $totalPages): ?>
                        <a href="comment.php?page=<?= $page + 1 ?>" class="page-link">Next</a>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <!-- Add Comment Form -->
                <?php if (empty($_POST["name"])): ?>
                    <form action="comment.php?s=add" method="post" style="width: 100%; height:fit-content;">
                        <input type="text" name="name" class="search1" placeholder="Enter your tracker ID">
                        <input type="submit" value="Submit" class="green" style="margin-top: 10px; margin-bottom:5px;">
                    </form>
                <?php else: ?>
                    <?php
                    $check = "SELECT * FROM tracker_user WHERE id = $1";
                    $result = pg_query_params($connetion, $check, array($_POST["name"]));
                    ?>
                    <?php if (pg_num_rows($result) > 0): ?>
                        <?php $_SESSION["id"] = $_POST["name"]; ?>
                        <form action="comment.php" method="post" style="width: 100%; height:fit-content;">
                            <div class="search1" style="display: flex; align-items: center;"><?= htmlspecialchars($_POST["name"]) ?></div>
                            <textarea name="comment" class="comment" style="margin-top: 10px;"></textarea>
                            <input type="submit" value="Submit" class="green" style="margin-top: 10px; margin-bottom:5px;">
                        </form>
                    <?php else: ?>
                        <p>Tracker ID <?= htmlspecialchars($_POST["name"]) ?> does not exist.</p>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <!-- Footer -->
        <div class="footer">
            <div class="footer1">
                <div class="equ">
                    <div class="equ1">
                        <h1 class="footerheader">Get In Touch</h1>
                       <p class="footertext" style="text-transform: lowercase;"> 6789 SOUTHPOINT PKWY STE 100 JACKSONVILLE FL 32216-8205, USA</p>
                        <p class="footertext">+1 208 2304 730</p>
                        <p class="footertext"> deliverixy@gmail.com</p>
                    </div>
                    <div class="equ1">
                        <h1 class="footerheader">Quick Links</h1>
                        <?php foreach ($link as $item): ?>
                            <a href="<?= $item ?>.php" class="footerlink"><?= ucfirst($item) ?></a>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <div class="footer2">
                <p class="footerlittle">© deliveri-X.</p>
            </div>
        </div>
    </div>
</body>

</html>